<?php
$type='Type1';
$name='PLECara';
$desc=array('Ascent'=>471,'Descent'=>-129,'CapHeight'=>533,'Flags'=>32,'FontBBox'=>'[-271 -238 570 905]','ItalicAngle'=>0,'StemV'=>70,'MissingWidth'=>500);
$up=-32;
$ut=5;
$cw=array(
	chr(0)=>500,chr(1)=>500,chr(2)=>500,chr(3)=>500,chr(4)=>500,chr(5)=>500,chr(6)=>500,chr(7)=>500,chr(8)=>500,chr(9)=>500,chr(10)=>500,chr(11)=>500,chr(12)=>500,chr(13)=>500,chr(14)=>500,chr(15)=>500,chr(16)=>500,chr(17)=>500,chr(18)=>500,chr(19)=>500,chr(20)=>500,chr(21)=>500,
	chr(22)=>500,chr(23)=>500,chr(24)=>500,chr(25)=>500,chr(26)=>500,chr(27)=>500,chr(28)=>500,chr(29)=>500,chr(30)=>500,chr(31)=>500,' '=>146,'!'=>146,'"'=>188,'#'=>363,'$'=>231,'%'=>394,'&'=>146,'\''=>131,'('=>219,')'=>233,'*'=>274,'+'=>272,
	','=>208,'-'=>276,'.'=>138,'/'=>257,'0'=>650,'1'=>176,'2'=>384,'3'=>396,'4'=>381,'5'=>374,'6'=>488,'7'=>295,'8'=>468,'9'=>491,':'=>137,';'=>131,'<'=>146,'='=>284,'>'=>146,'?'=>274,'@'=>467,'A'=>323,
	'B'=>269,'C'=>267,'D'=>275,'E'=>270,'F'=>265,'G'=>267,'H'=>311,'I'=>135,'J'=>212,'K'=>291,'L'=>207,'M'=>443,'N'=>291,'O'=>273,'P'=>262,'Q'=>326,'R'=>263,'S'=>277,'T'=>279,'U'=>281,'V'=>342,'W'=>445,
	'X'=>337,'Y'=>330,'Z'=>270,'['=>215,'\\'=>257,']'=>233,'^'=>146,'_'=>234,'`'=>190,'a'=>323,'b'=>269,'c'=>267,'d'=>275,'e'=>257,'f'=>265,'g'=>267,'h'=>311,'i'=>135,'j'=>212,'k'=>291,'l'=>207,'m'=>444,
	'n'=>291,'o'=>273,'p'=>262,'q'=>326,'r'=>263,'s'=>251,'t'=>279,'u'=>280,'v'=>342,'w'=>445,'x'=>337,'y'=>330,'z'=>270,'{'=>217,'|'=>135,'}'=>233,'~'=>146,chr(127)=>500,chr(128)=>500,chr(129)=>500,chr(130)=>500,chr(131)=>500,
	chr(132)=>500,chr(133)=>500,chr(134)=>500,chr(135)=>500,chr(136)=>500,chr(137)=>500,chr(138)=>500,chr(139)=>500,chr(140)=>500,chr(141)=>500,chr(142)=>500,chr(143)=>500,chr(144)=>500,chr(145)=>500,chr(146)=>500,chr(147)=>500,chr(148)=>500,chr(149)=>500,chr(150)=>500,chr(151)=>500,chr(152)=>500,chr(153)=>500,
	chr(154)=>500,chr(155)=>500,chr(156)=>500,chr(157)=>500,chr(158)=>500,chr(159)=>500,chr(160)=>146,chr(161)=>271,chr(162)=>268,chr(163)=>275,chr(164)=>271,chr(165)=>274,chr(166)=>335,chr(167)=>220,chr(168)=>273,chr(169)=>279,chr(170)=>264,chr(171)=>281,chr(172)=>359,chr(173)=>357,chr(174)=>323,chr(175)=>323,
	chr(176)=>271,chr(177)=>335,chr(178)=>359,chr(179)=>361,chr(180)=>268,chr(181)=>271,chr(182)=>270,chr(183)=>321,chr(184)=>273,chr(185)=>321,chr(186)=>320,chr(187)=>315,chr(188)=>316,chr(189)=>317,chr(190)=>321,chr(191)=>321,chr(192)=>320,chr(193)=>322,chr(194)=>271,chr(195)=>264,chr(196)=>268,chr(197)=>271,
	chr(198)=>318,chr(199)=>271,chr(200)=>270,chr(201)=>327,chr(202)=>268,chr(203)=>325,chr(204)=>322,chr(205)=>274,chr(206)=>279,chr(207)=>146,chr(208)=>188,chr(209)=>0,chr(210)=>271,chr(211)=>273,chr(212)=>0,chr(213)=>0,chr(214)=>0,chr(215)=>0,chr(216)=>0,chr(217)=>0,chr(218)=>0,chr(219)=>500,
	chr(220)=>500,chr(221)=>500,chr(222)=>500,chr(223)=>405,chr(224)=>131,chr(225)=>252,chr(226)=>159,chr(227)=>230,chr(228)=>220,chr(229)=>270,chr(230)=>260,chr(231)=>0,chr(232)=>0,chr(233)=>0,chr(234)=>0,chr(235)=>0,chr(236)=>0,chr(237)=>0,chr(238)=>146,chr(239)=>146,chr(240)=>649,chr(241)=>175,
	chr(242)=>383,chr(243)=>397,chr(244)=>383,chr(245)=>374,chr(246)=>492,chr(247)=>291,chr(248)=>468,chr(249)=>492,chr(250)=>146,chr(251)=>601,chr(252)=>500,chr(253)=>500,chr(254)=>500,chr(255)=>500);
$enc='iso-8859-11';
$diff='128 /.notdef 130 /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef 142 /.notdef 145 /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef 158 /.notdef /.notdef 161 /kokaithai /khokhaithai /khokhuatthai /khokhwaithai /khokhonthai /khorakhangthai /ngonguthai /chochanthai /chochingthai /chochangthai /sosothai /chochoethai /yoyingthai /dochadathai /topatakthai /thothanthai /thonangmonthothai /thophuthaothai /nonenthai /dodekthai /totaothai /thothungthai /thothahanthai /thothongthai /nonuthai /bobaimaithai /poplathai /phophungthai /fofathai /phophanthai /fofanthai /phosamphaothai /momathai /yoyakthai /roruathai /ruthai /lolingthai /luthai /wowaenthai /sosalathai /sorusithai /sosuathai /hohipthai /lochulathai /oangthai /honokhukthai /paiyannoithai /saraathai /maihanakatthai /saraaathai /saraamthai /saraithai /saraiithai /sarauethai /saraueethai /sarauthai /sarauuthai /phinthuthai /.notdef /.notdef /.notdef /.notdef /bahtthai /saraethai /saraaethai /saraothai /saraaimaimuanthai /saraaimaimalaithai /lakkhangyaothai /maiyamokthai /maitaikhuthai /maiekthai /maithothai /maitrithai /maichattawathai /thanthakhatthai /nikhahitthai /yamakkanthai /fongmanthai /zerothai /onethai /twothai /threethai /fourthai /fivethai /sixthai /seventhai /eightthai /ninethai /angkhankhuthai /khomutthai /.notdef /.notdef /.notdef /.notdef';
$file='plecara.z';
$size1=6094;
$size2=22699;
?>
