<?php
$type='Type1';
$name='AngsanaNew-Italic';
$desc=array('Ascent'=>923,'Descent'=>-239,'CapHeight'=>437,'Flags'=>96,'FontBBox'=>'[-324 -204 797 923]','ItalicAngle'=>-10,'StemV'=>70);
$up=-50;
$ut=25;
$cw=array(
	chr(0)=>600,chr(1)=>600,chr(2)=>600,chr(3)=>600,chr(4)=>600,chr(5)=>600,chr(6)=>600,chr(7)=>600,chr(8)=>600,chr(9)=>600,chr(10)=>600,chr(11)=>600,chr(12)=>600,chr(13)=>600,chr(14)=>600,chr(15)=>600,chr(16)=>600,chr(17)=>600,chr(18)=>600,chr(19)=>600,chr(20)=>600,chr(21)=>600,
	chr(22)=>600,chr(23)=>600,chr(24)=>600,chr(25)=>600,chr(26)=>600,chr(27)=>600,chr(28)=>600,chr(29)=>600,chr(30)=>600,chr(31)=>600,' '=>165,'!'=>220,'"'=>277,'#'=>330,'$'=>330,'%'=>550,'&'=>513,'\''=>141,'('=>220,')'=>220,'*'=>330,'+'=>445,
	','=>165,'-'=>220,'.'=>165,'/'=>183,'0'=>330,'1'=>330,'2'=>330,'3'=>330,'4'=>330,'5'=>330,'6'=>330,'7'=>330,'8'=>330,'9'=>330,':'=>220,';'=>220,'<'=>445,'='=>445,'>'=>445,'?'=>330,'@'=>607,'A'=>403,
	'B'=>403,'C'=>440,'D'=>477,'E'=>403,'F'=>403,'G'=>477,'H'=>477,'I'=>220,'J'=>293,'K'=>440,'L'=>367,'M'=>550,'N'=>440,'O'=>477,'P'=>403,'Q'=>477,'R'=>403,'S'=>330,'T'=>367,'U'=>477,'V'=>403,'W'=>550,
	'X'=>403,'Y'=>367,'Z'=>367,'['=>257,'\\'=>183,']'=>257,'^'=>279,'_'=>330,'`'=>220,'a'=>330,'b'=>330,'c'=>293,'d'=>330,'e'=>293,'f'=>183,'g'=>330,'h'=>330,'i'=>183,'j'=>183,'k'=>293,'l'=>183,'m'=>477,
	'n'=>330,'o'=>330,'p'=>330,'q'=>330,'r'=>257,'s'=>257,'t'=>183,'u'=>330,'v'=>293,'w'=>440,'x'=>293,'y'=>293,'z'=>257,'{'=>264,'|'=>181,'}'=>264,'~'=>357,chr(127)=>600,chr(128)=>330,chr(129)=>600,chr(130)=>600,chr(131)=>600,
	chr(132)=>600,chr(133)=>587,chr(134)=>600,chr(135)=>600,chr(136)=>600,chr(137)=>600,chr(138)=>600,chr(139)=>600,chr(140)=>600,chr(141)=>600,chr(142)=>600,chr(143)=>600,chr(144)=>600,chr(145)=>220,chr(146)=>220,chr(147)=>367,chr(148)=>367,chr(149)=>231,chr(150)=>330,chr(151)=>587,chr(152)=>600,chr(153)=>600,
	chr(154)=>600,chr(155)=>600,chr(156)=>600,chr(157)=>600,chr(158)=>600,chr(159)=>600,chr(160)=>165,chr(161)=>396,chr(162)=>398,chr(163)=>454,chr(164)=>398,chr(165)=>400,chr(166)=>484,chr(167)=>315,chr(168)=>355,chr(169)=>428,chr(170)=>405,chr(171)=>440,chr(172)=>506,chr(173)=>522,chr(174)=>420,chr(175)=>425,
	chr(176)=>378,chr(177)=>524,chr(178)=>521,chr(179)=>534,chr(180)=>400,chr(181)=>401,chr(182)=>394,chr(183)=>450,chr(184)=>380,chr(185)=>460,chr(186)=>450,chr(187)=>450,chr(188)=>391,chr(189)=>390,chr(190)=>464,chr(191)=>464,chr(192)=>414,chr(193)=>420,chr(194)=>343,chr(195)=>342,chr(196)=>395,chr(197)=>395,
	chr(198)=>415,chr(199)=>354,chr(200)=>390,chr(201)=>441,chr(202)=>440,chr(203)=>467,chr(204)=>455,chr(205)=>394,chr(206)=>371,chr(207)=>400,chr(208)=>358,chr(209)=>0,chr(210)=>285,chr(211)=>290,chr(212)=>0,chr(213)=>0,chr(214)=>0,chr(215)=>0,chr(216)=>0,chr(217)=>0,chr(218)=>0,chr(219)=>600,
	chr(220)=>600,chr(221)=>600,chr(222)=>600,chr(223)=>440,chr(224)=>168,chr(225)=>377,chr(226)=>342,chr(227)=>306,chr(228)=>344,chr(229)=>292,chr(230)=>425,chr(231)=>0,chr(232)=>0,chr(233)=>0,chr(234)=>0,chr(235)=>0,chr(236)=>0,chr(237)=>0,chr(238)=>0,chr(239)=>428,chr(240)=>402,chr(241)=>404,
	chr(242)=>568,chr(243)=>510,chr(244)=>512,chr(245)=>528,chr(246)=>427,chr(247)=>536,chr(248)=>502,chr(249)=>408,chr(250)=>471,chr(251)=>816,chr(252)=>600,chr(253)=>600,chr(254)=>600,chr(255)=>600);
$enc='cp874';
$diff='130 /.notdef /.notdef /.notdef 134 /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef 142 /.notdef 152 /.notdef /.notdef /.notdef /.notdef /.notdef 158 /.notdef /.notdef 161 /kokaithai /khokhaithai /khokhuatthai /khokhwaithai /khokhonthai /khorakhangthai /ngonguthai /chochanthai /chochingthai /chochangthai /sosothai /chochoethai /yoyingthai /dochadathai /topatakthai /thothanthai /thonangmonthothai /thophuthaothai /nonenthai /dodekthai /totaothai /thothungthai /thothahanthai /thothongthai /nonuthai /bobaimaithai /poplathai /phophungthai /fofathai /phophanthai /fofanthai /phosamphaothai /momathai /yoyakthai /roruathai /ruthai /lolingthai /luthai /wowaenthai /sosalathai /sorusithai /sosuathai /hohipthai /lochulathai /oangthai /honokhukthai /paiyannoithai /saraathai /maihanakatthai /saraaathai /saraamthai /saraithai /saraiithai /sarauethai /saraueethai /sarauthai /sarauuthai /phinthuthai /.notdef /.notdef /.notdef /.notdef /bahtthai /saraethai /saraaethai /saraothai /saraaimaimuanthai /saraaimaimalaithai /lakkhangyaothai /maiyamokthai /maitaikhuthai /maiekthai /maithothai /maitrithai /maichattawathai /thanthakhatthai /nikhahitthai /yamakkanthai /fongmanthai /zerothai /onethai /twothai /threethai /fourthai /fivethai /sixthai /seventhai /eightthai /ninethai /angkhankhuthai /khomutthai /.notdef /.notdef /.notdef /.notdef';
$file='angsai.z';
$size1=5995;
$size2=33740;
?>
