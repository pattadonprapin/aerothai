<?php
$type='Type1';
$name='KodchiangUPC-Italic';
$desc=array('Ascent'=>450,'Descent'=>-148,'CapHeight'=>437,'Flags'=>96,'FontBBox'=>'[-332 -194 882 699]','ItalicAngle'=>-9.9,'StemV'=>70);
$up=-32;
$ut=5;
$cw=array(
	chr(0)=>600,chr(1)=>600,chr(2)=>600,chr(3)=>600,chr(4)=>600,chr(5)=>600,chr(6)=>600,chr(7)=>600,chr(8)=>600,chr(9)=>600,chr(10)=>600,chr(11)=>600,chr(12)=>600,chr(13)=>600,chr(14)=>600,chr(15)=>600,chr(16)=>600,chr(17)=>600,chr(18)=>600,chr(19)=>600,chr(20)=>600,chr(21)=>600,
	chr(22)=>600,chr(23)=>600,chr(24)=>600,chr(25)=>600,chr(26)=>600,chr(27)=>600,chr(28)=>600,chr(29)=>600,chr(30)=>600,chr(31)=>600,' '=>220,'!'=>220,'"'=>269,'#'=>330,'$'=>330,'%'=>550,'&'=>513,'\''=>119,'('=>220,')'=>220,'*'=>330,'+'=>372,
	','=>165,'-'=>220,'.'=>165,'/'=>183,'0'=>343,'1'=>343,'2'=>343,'3'=>343,'4'=>343,'5'=>343,'6'=>343,'7'=>343,'8'=>343,'9'=>343,':'=>180,';'=>184,'<'=>343,'='=>401,'>'=>343,'?'=>293,'@'=>608,'A'=>477,
	'B'=>440,'C'=>440,'D'=>477,'E'=>403,'F'=>367,'G'=>477,'H'=>477,'I'=>220,'J'=>257,'K'=>477,'L'=>403,'M'=>587,'N'=>477,'O'=>477,'P'=>367,'Q'=>477,'R'=>440,'S'=>367,'T'=>403,'U'=>477,'V'=>477,'W'=>623,
	'X'=>477,'Y'=>477,'Z'=>403,'['=>220,'\\'=>183,']'=>220,'^'=>310,'_'=>330,'`'=>220,'a'=>293,'b'=>330,'c'=>293,'d'=>330,'e'=>293,'f'=>220,'g'=>330,'h'=>330,'i'=>183,'j'=>183,'k'=>330,'l'=>183,'m'=>513,
	'n'=>330,'o'=>330,'p'=>330,'q'=>330,'r'=>220,'s'=>257,'t'=>183,'u'=>330,'v'=>330,'w'=>477,'x'=>330,'y'=>330,'z'=>293,'{'=>317,'|'=>132,'}'=>317,'~'=>357,chr(127)=>600,chr(128)=>600,chr(129)=>600,chr(130)=>600,chr(131)=>600,
	chr(132)=>600,chr(133)=>600,chr(134)=>600,chr(135)=>600,chr(136)=>600,chr(137)=>600,chr(138)=>600,chr(139)=>600,chr(140)=>600,chr(141)=>600,chr(142)=>600,chr(143)=>600,chr(144)=>600,chr(145)=>600,chr(146)=>600,chr(147)=>600,chr(148)=>600,chr(149)=>600,chr(150)=>600,chr(151)=>600,chr(152)=>600,chr(153)=>600,
	chr(154)=>600,chr(155)=>600,chr(156)=>600,chr(157)=>600,chr(158)=>600,chr(159)=>600,chr(160)=>220,chr(161)=>378,chr(162)=>324,chr(163)=>327,chr(164)=>389,chr(165)=>388,chr(166)=>400,chr(167)=>288,chr(168)=>323,chr(169)=>370,chr(170)=>314,chr(171)=>318,chr(172)=>551,chr(173)=>545,chr(174)=>401,chr(175)=>398,
	chr(176)=>338,chr(177)=>403,chr(178)=>564,chr(179)=>551,chr(180)=>399,chr(181)=>401,chr(182)=>385,chr(183)=>409,chr(184)=>371,chr(185)=>398,chr(186)=>411,chr(187)=>412,chr(188)=>398,chr(189)=>402,chr(190)=>431,chr(191)=>427,chr(192)=>401,chr(193)=>406,chr(194)=>363,chr(195)=>323,chr(196)=>371,chr(197)=>366,
	chr(198)=>398,chr(199)=>319,chr(200)=>399,chr(201)=>402,chr(202)=>361,chr(203)=>401,chr(204)=>426,chr(205)=>358,chr(206)=>353,chr(207)=>478,chr(208)=>222,chr(209)=>0,chr(210)=>281,chr(211)=>275,chr(212)=>0,chr(213)=>0,chr(214)=>0,chr(215)=>0,chr(216)=>0,chr(217)=>0,chr(218)=>0,chr(219)=>600,
	chr(220)=>600,chr(221)=>600,chr(222)=>600,chr(223)=>462,chr(224)=>197,chr(225)=>350,chr(226)=>208,chr(227)=>214,chr(228)=>230,chr(229)=>278,chr(230)=>452,chr(231)=>0,chr(232)=>0,chr(233)=>0,chr(234)=>0,chr(235)=>0,chr(236)=>0,chr(237)=>0,chr(238)=>0,chr(239)=>510,chr(240)=>402,chr(241)=>410,
	chr(242)=>464,chr(243)=>428,chr(244)=>411,chr(245)=>411,chr(246)=>407,chr(247)=>501,chr(248)=>411,chr(249)=>481,chr(250)=>490,chr(251)=>896,chr(252)=>600,chr(253)=>600,chr(254)=>600,chr(255)=>600);
$enc='iso-8859-11';
$diff='128 /.notdef 130 /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef 142 /.notdef 145 /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef 158 /.notdef /.notdef 161 /kokaithai /khokhaithai /khokhuatthai /khokhwaithai /khokhonthai /khorakhangthai /ngonguthai /chochanthai /chochingthai /chochangthai /sosothai /chochoethai /yoyingthai /dochadathai /topatakthai /thothanthai /thonangmonthothai /thophuthaothai /nonenthai /dodekthai /totaothai /thothungthai /thothahanthai /thothongthai /nonuthai /bobaimaithai /poplathai /phophungthai /fofathai /phophanthai /fofanthai /phosamphaothai /momathai /yoyakthai /roruathai /ruthai /lolingthai /luthai /wowaenthai /sosalathai /sorusithai /sosuathai /hohipthai /lochulathai /oangthai /honokhukthai /paiyannoithai /saraathai /maihanakatthai /saraaathai /saraamthai /saraithai /saraiithai /sarauethai /saraueethai /sarauthai /sarauuthai /phinthuthai /.notdef /.notdef /.notdef /.notdef /bahtthai /saraethai /saraaethai /saraothai /saraaimaimuanthai /saraaimaimalaithai /lakkhangyaothai /maiyamokthai /maitaikhuthai /maiekthai /maithothai /maitrithai /maichattawathai /thanthakhatthai /nikhahitthai /yamakkanthai /fongmanthai /zerothai /onethai /twothai /threethai /fourthai /fivethai /sixthai /seventhai /eightthai /ninethai /angkhankhuthai /khomutthai /.notdef /.notdef /.notdef /.notdef';
$file='kodci.z';
$size1=5686;
$size2=30688;
?>
