<?php
$type='Type1';
$name='PLETomOutline';
$desc=array('Ascent'=>471,'Descent'=>-129,'CapHeight'=>454,'Flags'=>32,'FontBBox'=>'[-476 -275 662 881]','ItalicAngle'=>0,'StemV'=>70,'MissingWidth'=>500);
$up=-32;
$ut=5;
$cw=array(
	chr(0)=>500,chr(1)=>500,chr(2)=>500,chr(3)=>500,chr(4)=>500,chr(5)=>500,chr(6)=>500,chr(7)=>500,chr(8)=>500,chr(9)=>500,chr(10)=>500,chr(11)=>500,chr(12)=>500,chr(13)=>500,chr(14)=>500,chr(15)=>500,chr(16)=>500,chr(17)=>500,chr(18)=>500,chr(19)=>500,chr(20)=>500,chr(21)=>500,
	chr(22)=>500,chr(23)=>500,chr(24)=>500,chr(25)=>500,chr(26)=>500,chr(27)=>500,chr(28)=>500,chr(29)=>500,chr(30)=>500,chr(31)=>500,' '=>160,'!'=>225,'"'=>154,'#'=>453,'$'=>388,'%'=>315,'&'=>376,'\''=>109,'('=>230,')'=>250,'*'=>378,'+'=>319,
	','=>166,'-'=>405,'.'=>181,'/'=>384,'0'=>398,'1'=>180,'2'=>385,'3'=>389,'4'=>320,'5'=>386,'6'=>313,'7'=>332,'8'=>276,'9'=>366,':'=>209,';'=>195,'<'=>306,'='=>492,'>'=>312,'?'=>310,'@'=>411,'A'=>454,
	'B'=>501,'C'=>537,'D'=>615,'E'=>425,'F'=>370,'G'=>620,'H'=>393,'I'=>470,'J'=>529,'K'=>395,'L'=>567,'M'=>407,'N'=>503,'O'=>541,'P'=>467,'Q'=>567,'R'=>434,'S'=>489,'T'=>498,'U'=>406,'V'=>468,'W'=>483,
	'X'=>464,'Y'=>310,'Z'=>512,'['=>324,'\\'=>429,']'=>361,'^'=>237,'_'=>335,'`'=>136,'a'=>419,'b'=>386,'c'=>444,'d'=>446,'e'=>329,'f'=>354,'g'=>279,'h'=>362,'i'=>185,'j'=>304,'k'=>267,'l'=>174,'m'=>448,
	'n'=>321,'o'=>317,'p'=>358,'q'=>310,'r'=>309,'s'=>317,'t'=>322,'u'=>347,'v'=>351,'w'=>412,'x'=>291,'y'=>268,'z'=>317,'{'=>203,'|'=>145,'}'=>200,'~'=>307,chr(127)=>500,chr(128)=>500,chr(129)=>500,chr(130)=>500,chr(131)=>500,
	chr(132)=>500,chr(133)=>500,chr(134)=>500,chr(135)=>500,chr(136)=>500,chr(137)=>500,chr(138)=>500,chr(139)=>500,chr(140)=>500,chr(141)=>500,chr(142)=>500,chr(143)=>500,chr(144)=>500,chr(145)=>500,chr(146)=>500,chr(147)=>500,chr(148)=>500,chr(149)=>500,chr(150)=>500,chr(151)=>500,chr(152)=>500,chr(153)=>500,
	chr(154)=>500,chr(155)=>500,chr(156)=>500,chr(157)=>500,chr(158)=>500,chr(159)=>500,chr(160)=>160,chr(161)=>320,chr(162)=>255,chr(163)=>323,chr(164)=>337,chr(165)=>370,chr(166)=>399,chr(167)=>348,chr(168)=>386,chr(169)=>407,chr(170)=>234,chr(171)=>272,chr(172)=>412,chr(173)=>353,chr(174)=>332,chr(175)=>330,
	chr(176)=>323,chr(177)=>415,chr(178)=>542,chr(179)=>448,chr(180)=>382,chr(181)=>396,chr(182)=>340,chr(183)=>390,chr(184)=>312,chr(185)=>358,chr(186)=>365,chr(187)=>355,chr(188)=>419,chr(189)=>389,chr(190)=>429,chr(191)=>400,chr(192)=>330,chr(193)=>414,chr(194)=>345,chr(195)=>269,chr(196)=>400,chr(197)=>350,
	chr(198)=>338,chr(199)=>355,chr(200)=>344,chr(201)=>433,chr(202)=>317,chr(203)=>388,chr(204)=>365,chr(205)=>323,chr(206)=>334,chr(207)=>334,chr(208)=>218,chr(209)=>0,chr(210)=>195,chr(211)=>224,chr(212)=>0,chr(213)=>0,chr(214)=>0,chr(215)=>0,chr(216)=>0,chr(217)=>0,chr(218)=>0,chr(219)=>500,
	chr(220)=>500,chr(221)=>500,chr(222)=>500,chr(223)=>404,chr(224)=>186,chr(225)=>279,chr(226)=>208,chr(227)=>207,chr(228)=>212,chr(229)=>217,chr(230)=>298,chr(231)=>0,chr(232)=>0,chr(233)=>0,chr(234)=>0,chr(235)=>0,chr(236)=>0,chr(237)=>0,chr(238)=>0,chr(239)=>279,chr(240)=>376,chr(241)=>376,
	chr(242)=>382,chr(243)=>346,chr(244)=>389,chr(245)=>375,chr(246)=>383,chr(247)=>579,chr(248)=>542,chr(249)=>407,chr(250)=>390,chr(251)=>637,chr(252)=>500,chr(253)=>500,chr(254)=>500,chr(255)=>500);
$enc='iso-8859-11';
$diff='128 /.notdef 130 /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef 142 /.notdef 145 /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef 158 /.notdef /.notdef 161 /kokaithai /khokhaithai /khokhuatthai /khokhwaithai /khokhonthai /khorakhangthai /ngonguthai /chochanthai /chochingthai /chochangthai /sosothai /chochoethai /yoyingthai /dochadathai /topatakthai /thothanthai /thonangmonthothai /thophuthaothai /nonenthai /dodekthai /totaothai /thothungthai /thothahanthai /thothongthai /nonuthai /bobaimaithai /poplathai /phophungthai /fofathai /phophanthai /fofanthai /phosamphaothai /momathai /yoyakthai /roruathai /ruthai /lolingthai /luthai /wowaenthai /sosalathai /sorusithai /sosuathai /hohipthai /lochulathai /oangthai /honokhukthai /paiyannoithai /saraathai /maihanakatthai /saraaathai /saraamthai /saraithai /saraiithai /sarauethai /saraueethai /sarauthai /sarauuthai /phinthuthai /.notdef /.notdef /.notdef /.notdef /bahtthai /saraethai /saraaethai /saraothai /saraaimaimuanthai /saraaimaimalaithai /lakkhangyaothai /maiyamokthai /maitaikhuthai /maiekthai /maithothai /maitrithai /maichattawathai /thanthakhatthai /nikhahitthai /yamakkanthai /fongmanthai /zerothai /onethai /twothai /threethai /fourthai /fivethai /sixthai /seventhai /eightthai /ninethai /angkhankhuthai /khomutthai /.notdef /.notdef /.notdef /.notdef';
$file='pletomo.z';
$size1=6095;
$size2=60574;
?>
